import os
from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware
from pydantic import BaseModel
from dotenv import load_dotenv

# Load API keys
load_dotenv()
CEREBRAS_API_KEY = os.getenv("CEREBRAS_API_KEY")
LIQUIDMETAL_API_KEY = os.getenv("LIQUIDMETAL_API_KEY")

# Import SDKs
from cerebras_sdk import CerebrasClient
from lm_raindrop import Raindrop as LiquidMetalClient

# Initialize clients
c_client = CerebrasClient(api_key=CEREBRAS_API_KEY)
l_client = LiquidMetalClient(api_key=LIQUIDMETAL_API_KEY)

app = FastAPI()

app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

class ProblemRequest(BaseModel):
    problem_statement: str
    human_feedback: dict = None

@app.post("/mindweaver")
def run_mindweaver(request: ProblemRequest):
    raw_ideas = c_client.process(request.problem_statement)
    refined_input = {"cerebras_output": raw_ideas}
    if request.human_feedback:
        refined_input["human_feedback"] = request.human_feedback
    final_output = l_client.process(refined_input)
    return {"output": final_output}

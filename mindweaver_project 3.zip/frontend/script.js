async function submitProblem() {
    const problem = document.getElementById("problem").value;
    const response = await fetch("https://YOUR_BACKEND_URL/mindweaver", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ problem_statement: problem })
    });
    const data = await response.json();
    document.getElementById("output").innerText = JSON.stringify(data.output, null, 2);
}

import React from 'react';
export default function Header() {
  return (
    <header style={{padding: '1rem', backgroundColor: '#4b6cb7', color: 'white'}}>
      <h1>🌟 MindWeaver 🤝🤖🎨</h1>
      <p>Collaborative Human-AI Creativity Platform</p>
    </header>
  );
}
import React, { useEffect, useState } from 'react';
import { ElasticSearchClient } from '../services/elastic_client';
export default function IdeaList() {
  const [ideas, setIdeas] = useState([]);
  const esClient = new ElasticSearchClient();
  useEffect(() => {
    const fetchIdeas = async () => {
      const results = await esClient.search('mindweaver_ideas', 'creative');
      setIdeas(results);
    };
    fetchIdeas();
  }, []);
  return (
    <div style={{margin: '1rem'}}>
      <h2>💡 Ideas List</h2>
      {ideas.map((idea, i) => (
        <div key={i} style={{padding: '0.5rem', borderBottom: '1px solid #eee'}}>
          <strong>{idea.title}</strong>: {idea.content}
        </div>
      ))}
    </div>
  );
}
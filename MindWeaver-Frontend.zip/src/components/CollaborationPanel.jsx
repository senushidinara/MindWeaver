import React, { useEffect, useState } from 'react';
import { FiverrenClient } from '../services/fiverren_client';
export default function CollaborationPanel({ sessionName, users }) {
  const [messages, setMessages] = useState([]);
  const fivClient = new FiverrenClient();
  useEffect(() => {
    const session = fivClient.createSession(sessionName, users);
    const interval = setInterval(async () => {
      const updates = await fivClient.getSessionUpdates(session.id);
      setMessages(updates);
    }, 1000);
    return () => clearInterval(interval);
  }, [sessionName]);
  const sendMessage = async (msg) => {
    const session = await fivClient.getSessionByName(sessionName);
    await fivClient.sendMessage(session.id, users[0], msg);
  };
  return (
    <div style={{border: '1px solid #ccc', padding: '1rem', margin: '1rem'}}>
      <h2>💬 Collaboration Panel</h2>
      <div style={{maxHeight: '200px', overflowY: 'scroll'}}>
        {messages.map((m, i) => (
          <p key={i}>🗨️ {m.user}: {m.message}</p>
        ))}
      </div>
      <input placeholder="Type a message..." onKeyDown={(e) => {
        if (e.key === 'Enter') sendMessage(e.target.value);
      }} />
    </div>
  );
}
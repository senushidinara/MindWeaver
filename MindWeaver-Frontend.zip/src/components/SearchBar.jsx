import React, { useState } from 'react';
import { ElasticSearchClient } from '../services/elastic_client';
export default function SearchBar() {
  const [query, setQuery] = useState('');
  const [results, setResults] = useState([]);
  const esClient = new ElasticSearchClient();
  const search = async () => {
    const res = await esClient.search('mindweaver_ideas', query);
    setResults(res);
  };
  return (
    <div style={{margin: '1rem'}}>
      <input placeholder="Search ideas..." value={query} onChange={(e) => setQuery(e.target.value)} />
      <button onClick={search}>🔍 Search</button>
      <div>{results.map((r, i) => <p key={i}>💡 {r.title}: {r.content}</p>)}</div>
    </div>
  );
}
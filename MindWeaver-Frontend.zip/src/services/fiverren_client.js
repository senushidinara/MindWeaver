export class FiverrenClient {
  constructor() { this.sessions = {}; }
  createSession(name, users) { const id = `sess_${Date.now()}`; this.sessions[id] = { name, users, messages: [] }; return { id, name }; }
  sendMessage(session_id, user_id, message) { if(this.sessions[session_id]) { this.sessions[session_id].messages.push({ user: user_id, message }); } }
  async getSessionUpdates(session_id) { if(this.sessions[session_id]) { return this.sessions[session_id].messages; } return []; }
  getSessionByName(name) { const id = Object.keys(this.sessions).find(id => this.sessions[id].name === name); return { id }; }
}
import { Client } from '@elastic/elasticsearch';
export class ElasticSearchClient {
  constructor() {
    this.client = new Client({ cloud: { id: process.env.ELASTIC_CLOUD_ID }, auth: { apiKey: process.env.ELASTIC_API_KEY } });
  }
  async index(index, document) { await this.client.index({ index, document }); }
  async search(index, query) { const result = await this.client.search({ index, query: { match: { title: query } } }); return result.hits.hits.map(hit => hit._source); }
}
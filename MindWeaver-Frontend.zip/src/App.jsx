import React from 'react';
import Header from './components/Header';
import CollaborationPanel from './components/CollaborationPanel';
import IdeaList from './components/IdeaList';
import SearchBar from './components/SearchBar';
export default function App() {
  return (
    <div>
      <Header />
      <CollaborationPanel sessionName="ProteinFoldingTeam" users={["user1", "ai_agent1"]} />
      <SearchBar />
      <IdeaList />
    </div>
  );
}